NORTHWEST TIGERS FOOTBALL — EXPANDED DEMO

Open Northwest_Tigers_Football.html in Safari, Chrome, or another modern browser.
It is a self-contained browser game and needs no paid software.

Features:
- Northwest Tigers branding
- Christian #17 as QB
- Fictional roster placeholders
- Player ratings
- Play selection
- Downs and yards-to-go
- Touchdowns, field goals, XP, lives
- Mobile controls
- Season-style progression

For a public no-download link, publish the HTML file through a static host such as GitHub Pages.
